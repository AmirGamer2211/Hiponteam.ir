<?php get_header(); ?>
<h1>Welcome to My Hacker Theme</h1>
<p>This is the home page.</p>
<?php get_footer(); ?>
