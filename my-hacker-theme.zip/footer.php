<footer>
    <p>&copy; 2024 My Hacker Theme. All rights reserved.</p>
    <?php wp_footer(); ?>
</footer>
</body>
</html>
